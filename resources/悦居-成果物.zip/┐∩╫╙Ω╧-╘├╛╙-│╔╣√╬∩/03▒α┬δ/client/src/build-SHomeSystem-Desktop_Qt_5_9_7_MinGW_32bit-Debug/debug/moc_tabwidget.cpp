/****************************************************************************
** Meta object code from reading C++ file 'tabwidget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.9.7)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../SHomeSystem/tabwidget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'tabwidget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.9.7. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_TabWidget_t {
    QByteArrayData data[58];
    char stringdata0[1263];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_TabWidget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_TabWidget_t qt_meta_stringdata_TabWidget = {
    {
QT_MOC_LITERAL(0, 0, 9), // "TabWidget"
QT_MOC_LITERAL(1, 10, 12), // "dataReceived"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 10), // "deviceName"
QT_MOC_LITERAL(4, 35, 10), // "totalPower"
QT_MOC_LITERAL(5, 46, 26), // "onServerConnectionFinished"
QT_MOC_LITERAL(6, 73, 15), // "handleTabChange"
QT_MOC_LITERAL(7, 89, 27), // "sendDeviceTotalPowerRequest"
QT_MOC_LITERAL(8, 117, 3), // "url"
QT_MOC_LITERAL(9, 121, 19), // "sendAirDataToServer"
QT_MOC_LITERAL(10, 141, 13), // "Device::State"
QT_MOC_LITERAL(11, 155, 5), // "state"
QT_MOC_LITERAL(12, 161, 11), // "temperature"
QT_MOC_LITERAL(13, 173, 10), // "QDateTime&"
QT_MOC_LITERAL(14, 184, 9), // "timestamp"
QT_MOC_LITERAL(15, 194, 23), // "AirConditioner::AirMode"
QT_MOC_LITERAL(16, 218, 4), // "mode"
QT_MOC_LITERAL(17, 223, 21), // "sendLightDataToServer"
QT_MOC_LITERAL(18, 245, 16), // "Light::LightMode"
QT_MOC_LITERAL(19, 262, 24), // "sendHumidityDataToServer"
QT_MOC_LITERAL(20, 287, 8), // "humidity"
QT_MOC_LITERAL(21, 296, 28), // "onHostAirEditEditingFinished"
QT_MOC_LITERAL(22, 325, 30), // "onLivingAirEditEditingFinished"
QT_MOC_LITERAL(23, 356, 30), // "onSecondAirEditEditingFinished"
QT_MOC_LITERAL(24, 387, 28), // "onLivingAirTimeButtonClicked"
QT_MOC_LITERAL(25, 416, 26), // "onHostAirTimeButtonClicked"
QT_MOC_LITERAL(26, 443, 28), // "onSecondAirTimeButtonClicked"
QT_MOC_LITERAL(27, 472, 27), // "onHostAirPowerButtonClicked"
QT_MOC_LITERAL(28, 500, 29), // "onLivingAirPowerButtonClicked"
QT_MOC_LITERAL(29, 530, 29), // "onSecondAirPowerButtonClicked"
QT_MOC_LITERAL(30, 560, 20), // "onHostAirModeChanged"
QT_MOC_LITERAL(31, 581, 5), // "index"
QT_MOC_LITERAL(32, 587, 22), // "onLivingAirModeChanged"
QT_MOC_LITERAL(33, 610, 22), // "onSecondAirModeChanged"
QT_MOC_LITERAL(34, 633, 24), // "updateHostAirStatusLabel"
QT_MOC_LITERAL(35, 658, 26), // "updateLivingAirStatusLabel"
QT_MOC_LITERAL(36, 685, 26), // "updateSecondAirStatusLabel"
QT_MOC_LITERAL(37, 712, 29), // "updateHostHumidityStatusLabel"
QT_MOC_LITERAL(38, 742, 31), // "updateLivingHumidityStatusLabel"
QT_MOC_LITERAL(39, 774, 24), // "onHostHumidityBtnClicked"
QT_MOC_LITERAL(40, 799, 26), // "onLivingHumidityBtnClicked"
QT_MOC_LITERAL(41, 826, 27), // "onHostHumiditySliderChanged"
QT_MOC_LITERAL(42, 854, 5), // "value"
QT_MOC_LITERAL(43, 860, 29), // "onLivingHumiditySliderChanged"
QT_MOC_LITERAL(44, 890, 25), // "onHostHumiditySpinChanged"
QT_MOC_LITERAL(45, 916, 27), // "onLivingHumiditySpinChanged"
QT_MOC_LITERAL(46, 944, 26), // "updateHostLightStatusLabel"
QT_MOC_LITERAL(47, 971, 28), // "updateLivingLightStatusLabel"
QT_MOC_LITERAL(48, 1000, 28), // "updateSecondLightStatusLabel"
QT_MOC_LITERAL(49, 1029, 22), // "onHostLightModeChanged"
QT_MOC_LITERAL(50, 1052, 24), // "onLivingLightModeChanged"
QT_MOC_LITERAL(51, 1077, 24), // "onSecondLightModeChanged"
QT_MOC_LITERAL(52, 1102, 24), // "onHostLightButtonClicked"
QT_MOC_LITERAL(53, 1127, 26), // "onLivingLightButtonClicked"
QT_MOC_LITERAL(54, 1154, 26), // "onSecondLightButtonClicked"
QT_MOC_LITERAL(55, 1181, 25), // "onHostLightTimeBtnClicked"
QT_MOC_LITERAL(56, 1207, 27), // "onLivingLightTimeBtnClicked"
QT_MOC_LITERAL(57, 1235, 27) // "onSecondLightTimeBtnClicked"

    },
    "TabWidget\0dataReceived\0\0deviceName\0"
    "totalPower\0onServerConnectionFinished\0"
    "handleTabChange\0sendDeviceTotalPowerRequest\0"
    "url\0sendAirDataToServer\0Device::State\0"
    "state\0temperature\0QDateTime&\0timestamp\0"
    "AirConditioner::AirMode\0mode\0"
    "sendLightDataToServer\0Light::LightMode\0"
    "sendHumidityDataToServer\0humidity\0"
    "onHostAirEditEditingFinished\0"
    "onLivingAirEditEditingFinished\0"
    "onSecondAirEditEditingFinished\0"
    "onLivingAirTimeButtonClicked\0"
    "onHostAirTimeButtonClicked\0"
    "onSecondAirTimeButtonClicked\0"
    "onHostAirPowerButtonClicked\0"
    "onLivingAirPowerButtonClicked\0"
    "onSecondAirPowerButtonClicked\0"
    "onHostAirModeChanged\0index\0"
    "onLivingAirModeChanged\0onSecondAirModeChanged\0"
    "updateHostAirStatusLabel\0"
    "updateLivingAirStatusLabel\0"
    "updateSecondAirStatusLabel\0"
    "updateHostHumidityStatusLabel\0"
    "updateLivingHumidityStatusLabel\0"
    "onHostHumidityBtnClicked\0"
    "onLivingHumidityBtnClicked\0"
    "onHostHumiditySliderChanged\0value\0"
    "onLivingHumiditySliderChanged\0"
    "onHostHumiditySpinChanged\0"
    "onLivingHumiditySpinChanged\0"
    "updateHostLightStatusLabel\0"
    "updateLivingLightStatusLabel\0"
    "updateSecondLightStatusLabel\0"
    "onHostLightModeChanged\0onLivingLightModeChanged\0"
    "onSecondLightModeChanged\0"
    "onHostLightButtonClicked\0"
    "onLivingLightButtonClicked\0"
    "onSecondLightButtonClicked\0"
    "onHostLightTimeBtnClicked\0"
    "onLivingLightTimeBtnClicked\0"
    "onSecondLightTimeBtnClicked"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_TabWidget[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      42,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       1,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,  224,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       5,    0,  229,    2, 0x0a /* Public */,
       6,    1,  230,    2, 0x0a /* Public */,
       7,    2,  233,    2, 0x0a /* Public */,
       9,    5,  238,    2, 0x0a /* Public */,
      17,    4,  249,    2, 0x0a /* Public */,
      19,    4,  258,    2, 0x0a /* Public */,
      21,    0,  267,    2, 0x0a /* Public */,
      22,    0,  268,    2, 0x0a /* Public */,
      23,    0,  269,    2, 0x0a /* Public */,
      24,    0,  270,    2, 0x0a /* Public */,
      25,    0,  271,    2, 0x0a /* Public */,
      26,    0,  272,    2, 0x0a /* Public */,
      27,    0,  273,    2, 0x0a /* Public */,
      28,    0,  274,    2, 0x0a /* Public */,
      29,    0,  275,    2, 0x0a /* Public */,
      30,    1,  276,    2, 0x0a /* Public */,
      32,    1,  279,    2, 0x0a /* Public */,
      33,    1,  282,    2, 0x0a /* Public */,
      34,    0,  285,    2, 0x0a /* Public */,
      35,    0,  286,    2, 0x0a /* Public */,
      36,    0,  287,    2, 0x0a /* Public */,
      37,    1,  288,    2, 0x0a /* Public */,
      38,    1,  291,    2, 0x0a /* Public */,
      39,    0,  294,    2, 0x0a /* Public */,
      40,    0,  295,    2, 0x0a /* Public */,
      41,    1,  296,    2, 0x0a /* Public */,
      43,    1,  299,    2, 0x0a /* Public */,
      44,    1,  302,    2, 0x0a /* Public */,
      45,    1,  305,    2, 0x0a /* Public */,
      46,    0,  308,    2, 0x0a /* Public */,
      47,    0,  309,    2, 0x0a /* Public */,
      48,    0,  310,    2, 0x0a /* Public */,
      49,    1,  311,    2, 0x0a /* Public */,
      50,    1,  314,    2, 0x0a /* Public */,
      51,    1,  317,    2, 0x0a /* Public */,
      52,    0,  320,    2, 0x0a /* Public */,
      53,    0,  321,    2, 0x0a /* Public */,
      54,    0,  322,    2, 0x0a /* Public */,
      55,    0,  323,    2, 0x0a /* Public */,
      56,    0,  324,    2, 0x0a /* Public */,
      57,    0,  325,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void, QMetaType::QString, QMetaType::Double,    3,    4,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,    2,
    QMetaType::Void, QMetaType::QString, QMetaType::QString,    8,    3,
    QMetaType::Void, 0x80000000 | 10, QMetaType::Double, 0x80000000 | 13, 0x80000000 | 15, QMetaType::QString,   11,   12,   14,   16,    3,
    QMetaType::Void, 0x80000000 | 10, 0x80000000 | 13, 0x80000000 | 18, QMetaType::QString,   11,   14,   16,    3,
    QMetaType::Void, 0x80000000 | 10, QMetaType::Double, 0x80000000 | 13, QMetaType::QString,   11,   20,   14,    3,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void, QMetaType::Int,   42,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void, QMetaType::Int,   31,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void TabWidget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        TabWidget *_t = static_cast<TabWidget *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->dataReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2]))); break;
        case 1: _t->onServerConnectionFinished(); break;
        case 2: _t->handleTabChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 3: _t->sendDeviceTotalPowerRequest((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QString(*)>(_a[2]))); break;
        case 4: _t->sendAirDataToServer((*reinterpret_cast< Device::State(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< QDateTime(*)>(_a[3])),(*reinterpret_cast< AirConditioner::AirMode(*)>(_a[4])),(*reinterpret_cast< const QString(*)>(_a[5]))); break;
        case 5: _t->sendLightDataToServer((*reinterpret_cast< Device::State(*)>(_a[1])),(*reinterpret_cast< QDateTime(*)>(_a[2])),(*reinterpret_cast< Light::LightMode(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4]))); break;
        case 6: _t->sendHumidityDataToServer((*reinterpret_cast< Device::State(*)>(_a[1])),(*reinterpret_cast< double(*)>(_a[2])),(*reinterpret_cast< QDateTime(*)>(_a[3])),(*reinterpret_cast< const QString(*)>(_a[4]))); break;
        case 7: _t->onHostAirEditEditingFinished(); break;
        case 8: _t->onLivingAirEditEditingFinished(); break;
        case 9: _t->onSecondAirEditEditingFinished(); break;
        case 10: _t->onLivingAirTimeButtonClicked(); break;
        case 11: _t->onHostAirTimeButtonClicked(); break;
        case 12: _t->onSecondAirTimeButtonClicked(); break;
        case 13: _t->onHostAirPowerButtonClicked(); break;
        case 14: _t->onLivingAirPowerButtonClicked(); break;
        case 15: _t->onSecondAirPowerButtonClicked(); break;
        case 16: _t->onHostAirModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 17: _t->onLivingAirModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 18: _t->onSecondAirModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 19: _t->updateHostAirStatusLabel(); break;
        case 20: _t->updateLivingAirStatusLabel(); break;
        case 21: _t->updateSecondAirStatusLabel(); break;
        case 22: _t->updateHostHumidityStatusLabel((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 23: _t->updateLivingHumidityStatusLabel((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 24: _t->onHostHumidityBtnClicked(); break;
        case 25: _t->onLivingHumidityBtnClicked(); break;
        case 26: _t->onHostHumiditySliderChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 27: _t->onLivingHumiditySliderChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 28: _t->onHostHumiditySpinChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 29: _t->onLivingHumiditySpinChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->updateHostLightStatusLabel(); break;
        case 31: _t->updateLivingLightStatusLabel(); break;
        case 32: _t->updateSecondLightStatusLabel(); break;
        case 33: _t->onHostLightModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 34: _t->onLivingLightModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->onSecondLightModeChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 36: _t->onHostLightButtonClicked(); break;
        case 37: _t->onLivingLightButtonClicked(); break;
        case 38: _t->onSecondLightButtonClicked(); break;
        case 39: _t->onHostLightTimeBtnClicked(); break;
        case 40: _t->onLivingLightTimeBtnClicked(); break;
        case 41: _t->onSecondLightTimeBtnClicked(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (TabWidget::*_t)(const QString & , double );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&TabWidget::dataReceived)) {
                *result = 0;
                return;
            }
        }
    }
}

const QMetaObject TabWidget::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_TabWidget.data,
      qt_meta_data_TabWidget,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *TabWidget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *TabWidget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_TabWidget.stringdata0))
        return static_cast<void*>(this);
    return QWidget::qt_metacast(_clname);
}

int TabWidget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 42)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 42;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 42)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 42;
    }
    return _id;
}

// SIGNAL 0
void TabWidget::dataReceived(const QString & _t1, double _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
